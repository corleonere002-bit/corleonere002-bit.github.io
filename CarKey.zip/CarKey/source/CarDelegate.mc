import Toybox.Application;
import Toybox.Lang;
import Toybox.WatchUi;

class CarDelegate extends WatchUi.BehaviorDelegate {

    var mApi;
    var mView;

    function initialize(api, view) {
        BehaviorDelegate.initialize();
        mApi = api;
        mView = view;
    }

    function onSelect() {
        openMenu();
        return true;
    }

    function onMenu() {
        openMenu();
        return true;
    }

    function onTap(evt) {
        var xy = evt.getCoordinates();
        var slot = mView.hit(xy[0], xy[1]);
        var b = (slot < 0) ? -1 : mView.slotType(slot);
        if (b == 0) {
            if (mView.isLocked()) {
                ask(mApi, A_UNLOCK);
            } else {
                mApi.start(A_LOCK);
            }
        } else if (b == 1) {
            mApi.start(mView.isClimateOn() ? A_CLIMATE_OFF : A_CLIMATE_ON);
        } else if (b == 2) {
            ask(mApi, A_FRUNK);
        } else if (b == 3) {
            ask(mApi, A_TRUNK);
        } else if (b == 4) {
            mApi.start(A_FLASH);
        } else if (b == 5) {
            mApi.start(A_HONK);
        } else if (b == 6) {
            mApi.start(A_REFRESH);
        } else {
            openMenu();
        }
        return true;
    }

    function openMenu() {
        var m = new WatchUi.Menu2({:title => "Car"});
        m.addItem(new WatchUi.MenuItem("Unlock", null, A_UNLOCK, null));
        m.addItem(new WatchUi.MenuItem("Lock", null, A_LOCK, null));
        m.addItem(new WatchUi.MenuItem("Climate on", null, A_CLIMATE_ON, null));
        m.addItem(new WatchUi.MenuItem("Climate off", null, A_CLIMATE_OFF, null));
        m.addItem(new WatchUi.MenuItem("Open frunk", null, A_FRUNK, null));
        m.addItem(new WatchUi.MenuItem("Open / close trunk", null, A_TRUNK, null));
        m.addItem(new WatchUi.MenuItem("Flash lights", null, A_FLASH, null));
        m.addItem(new WatchUi.MenuItem("Honk", null, A_HONK, null));
        m.addItem(new WatchUi.MenuItem("Refresh", null, A_REFRESH, null));
        m.addItem(new WatchUi.MenuItem("Wake & refresh", null, A_WAKE, null));
        WatchUi.pushView(m, new CarMenuDelegate(mApi), WatchUi.SLIDE_UP);
    }
}

class CarMenuDelegate extends WatchUi.Menu2InputDelegate {

    var mApi;

    function initialize(api) {
        Menu2InputDelegate.initialize();
        mApi = api;
    }

    function onSelect(item) {
        var id = item.getId();
        WatchUi.popView(WatchUi.SLIDE_DOWN);
        if (id == A_UNLOCK || id == A_FRUNK || id == A_TRUNK) {
            ask(mApi, id);
            return;
        }
        mApi.start(id);
    }
}

// opening actions ask first; unlock only when "Ask before unlocking" is on
function ask(api, action) {
    var confirm = true;
    if (action == A_UNLOCK) {
        try {
            confirm = (Application.Properties.getValue("ConfirmUnlock") != false);
        } catch (e) {
            confirm = true;
        }
    }
    if (!confirm) {
        api.start(action);
        return;
    }
    var q = "Unlock car?";
    if (action == A_FRUNK) { q = "Open frunk?"; }
    if (action == A_TRUNK) { q = "Open / close trunk?"; }
    WatchUi.pushView(new WatchUi.Confirmation(q), new AskConfirm(api, action), WatchUi.SLIDE_IMMEDIATE);
}

class AskConfirm extends WatchUi.ConfirmationDelegate {

    var mApi;
    var mAction;

    function initialize(api, action) {
        ConfirmationDelegate.initialize();
        mApi = api;
        mAction = action;
    }

    function onResponse(response) {
        if (response == WatchUi.CONFIRM_YES) {
            mApi.start(mAction);
        }
        return true;
    }
}
