import Toybox.Application;
import Toybox.Graphics;
import Toybox.Lang;
import Toybox.WatchUi;

(:glance)
class CarGlance extends WatchUi.GlanceView {

    function initialize() {
        GlanceView.initialize();
    }

    function onUpdate(dc) {
        var c = null;
        try {
            c = Application.Storage.getValue("cache");
        } catch (e) {
            c = null;
        }
        var name = "CAR KEY";
        var line = "Open to connect";
        if (c instanceof Lang.Dictionary) {
            if (c["name"] instanceof Lang.String) {
                name = c["name"].toUpper();
            }
            var parts = "";
            if (c["bat"] instanceof Lang.Number) {
                parts = c["bat"].toString() + "%";
            }
            if (c["lock"] != null) {
                parts = parts + (parts.length() > 0 ? "  " : "") + (c["lock"] == true ? "Locked" : "Unlocked");
            }
            if (parts.length() > 0) {
                line = parts;
            }
        }
        var h = dc.getHeight();
        var w = dc.getWidth();
        dc.setColor(Graphics.COLOR_WHITE, Graphics.COLOR_TRANSPARENT);
        dc.drawText(0, h * 0.22, Graphics.FONT_GLANCE, name, Graphics.TEXT_JUSTIFY_LEFT | Graphics.TEXT_JUSTIFY_VCENTER);
        var unlocked = (c instanceof Lang.Dictionary) && c["lock"] == false;
        dc.setColor(unlocked ? 0xD63030 : 0xF0F0F0, Graphics.COLOR_TRANSPARENT);
        dc.drawText(0, h * 0.58, Graphics.FONT_GLANCE_NUMBER, line, Graphics.TEXT_JUSTIFY_LEFT | Graphics.TEXT_JUSTIFY_VCENTER);
        // battery bar
        var bat = (c instanceof Lang.Dictionary && c["bat"] instanceof Lang.Number) ? c["bat"] : null;
        if (bat != null) {
            var bh = (h * 0.08).toNumber();
            if (bh < 4) { bh = 4; }
            var by = (h * 0.88).toNumber();
            var bw = (w * 0.8).toNumber();
            dc.setColor(0x23262C, Graphics.COLOR_TRANSPARENT);
            dc.fillRoundedRectangle(0, by, bw, bh, bh / 2);
            dc.setColor((bat <= 20) ? 0xD63030 : ((bat <= 40) ? 0xF2B23A : 0x3DD68C), Graphics.COLOR_TRANSPARENT);
            var fw = (bw * (bat > 100 ? 100 : bat) / 100.0).toNumber();
            if (fw > bh) {
                dc.fillRoundedRectangle(0, by, fw, bh, bh / 2);
            }
        }
    }
}
