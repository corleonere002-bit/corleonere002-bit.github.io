import Toybox.Application;
import Toybox.Graphics;
import Toybox.Lang;
import Toybox.Math;
import Toybox.System;
import Toybox.Time;
import Toybox.WatchUi;

class CarView extends WatchUi.View {

    const RED = 0xD63030;
    const GREEN = 0x3DD68C;
    const AMBER = 0xF2B23A;
    const GREY = 0x8A8F98;
    const DARK = 0x23262C;
    const BTN = 0x1A1C21;
    const WH = 0xF0F0F0;

    // button grid (design coordinates for 454 px): x, y, action
    var BX = [107, 227, 347];
    var BY = [272, 272, 272];
    const BR = 46;

    var mApi;
    var mStarted = false;
    var mK = 1.0;

    function initialize(api) {
        View.initialize();
        mApi = api;
    }

    function onShow() {
        if (!mStarted) {
            mStarted = true;
            mApi.start(A_REFRESH);
        }
    }

    function cache() {
        try {
            var c = Application.Storage.getValue("cache");
            return (c instanceof Lang.Dictionary) ? c : {};
        } catch (e) {
            return {};
        }
    }

    function miles() {
        try {
            return Application.Properties.getValue("Units") == 1;
        } catch (e) {
            return false;
        }
    }

    function s(v) {
        return (v * mK).toNumber();
    }

    // index of the button under a tap (0..5), -1 if none
    function hit(x, y) {
        for (var i = 0; i < 3; i++) {
            var dx = x - s(BX[i]);
            var dy = y - s(BY[i]);
            var rr = s(BR + 6);
            if (dx * dx + dy * dy <= rr * rr && slotType(i) != 7) {
                return i;
            }
        }
        return -1;
    }

    // what each of the 6 places shows (from the phone settings)
    // 0 lock, 1 climate, 2 frunk, 3 trunk, 4 lights, 5 horn, 6 refresh, 7 empty
    function slotType(i) {
        var d = [0, 1, 2];
        try {
            var v = Application.Properties.getValue("Btn" + (i + 1).toString());
            if (v instanceof Lang.Number && v >= 0 && v <= 7) {
                return v;
            }
        } catch (e) {
        }
        return d[i];
    }

    function isLocked() {
        return cache()["lock"] != false;
    }

    function isClimateOn() {
        return cache()["clim"] == true;
    }

    function fit(dc, t, font, max) {
        if (dc.getTextWidthInPixels(t, font) <= max) {
            return t;
        }
        while (t.length() > 4 && dc.getTextWidthInPixels(t + "...", font) > max) {
            t = t.substring(0, t.length() - 1);
        }
        return t + "...";
    }

    function onUpdate(dc) {
        var w = dc.getWidth();
        mK = w / 454.0;
        var cx = w / 2;
        if (dc has :setAntiAlias) {
            dc.setAntiAlias(true);
        }
        dc.setColor(Graphics.COLOR_BLACK, Graphics.COLOR_BLACK);
        dc.clear();
        var c = cache();
        var CC = Graphics.TEXT_JUSTIFY_CENTER | Graphics.TEXT_JUSTIFY_VCENTER;

        // battery arc along the edge (from lower left, over the top, to lower right)
        var bat = (c["bat"] instanceof Lang.Number) ? c["bat"] : null;
        dc.setPenWidth(s(8));
        dc.setColor(DARK, Graphics.COLOR_TRANSPARENT);
        dc.drawArc(cx, cx, s(214), Graphics.ARC_CLOCKWISE, 210, 330);
        if (bat != null && bat > 0) {
            dc.setColor((bat <= 20) ? RED : ((bat <= 40) ? AMBER : GREEN), Graphics.COLOR_TRANSPARENT);
            var endA = 210 - 240.0 * (bat > 100 ? 100 : bat) / 100.0;
            if (endA < 0) { endA += 360; }
            dc.drawArc(cx, cx, s(214), Graphics.ARC_CLOCKWISE, 210, endA.toNumber());
        }
        dc.setPenWidth(1);

        // header
        var name = (c["name"] instanceof Lang.String) ? c["name"].toUpper() : "CAR KEY";
        dc.setColor(GREY, Graphics.COLOR_TRANSPARENT);
        dc.drawText(cx, s(54), Graphics.FONT_XTINY, fit(dc, name, Graphics.FONT_XTINY, s(220)), CC);
        dc.setColor(WH, Graphics.COLOR_TRANSPARENT);
        dc.drawText(cx, s(128), Graphics.FONT_NUMBER_MEDIUM, (bat != null) ? bat.toString() + "%" : "--", CC);
        var rng = c["rng"];
        var rs = "-- km";
        if (rng instanceof Lang.Float || rng instanceof Lang.Number || rng instanceof Lang.Double) {
            rs = miles() ? rng.toNumber().toString() + " mi" : (rng * 1.609344).toNumber().toString() + " km";
        }
        var chg = "Charging".equals(c["chg"]);
        if (chg) {
            rs = rs + "  -  Charging";
        }
        dc.setColor(chg ? GREEN : GREY, Graphics.COLOR_TRANSPARENT);
        dc.drawText(cx, s(192), Graphics.FONT_XTINY, rs, CC);

        // buttons
        var locked = isLocked();
        var clim = isClimateOn();
        for (var i = 0; i < 3; i++) {
            var t = slotType(i);
            if (t != 7) {
                drawButton(dc, i, t, locked, clim);
            }
        }

        // status, with the inside temperature when idle
        var st = mApi.mStatus;
        if (st.length() == 0 && "asleep".equals(c["state"])) {
            st = "Car asleep";
        }
        if (!mApi.mBusy && !mApi.mError
            && (c["in"] instanceof Lang.Float || c["in"] instanceof Lang.Number || c["in"] instanceof Lang.Double)) {
            st = st + (st.length() > 0 ? "  |  " : "") + c["in"].toNumber().toString() + "°C";
        }
        dc.setColor(mApi.mError ? RED : (mApi.mBusy ? AMBER : GREY), Graphics.COLOR_TRANSPARENT);
        dc.drawText(cx, s(362), Graphics.FONT_XTINY, fit(dc, st, Graphics.FONT_XTINY, s(320)), CC);
    }

    function drawButton(dc, i, t, locked, clim) {
        var x = s(BX[i]);
        var y = s(BY[i]);
        var r = s(BR);
        var fill = BTN;
        var ring = RED;
        if (t == 0 && !locked) { fill = 0x3C1212; }
        if (t == 1 && clim) { fill = 0x0E3424; ring = GREEN; }
        dc.setColor(fill, Graphics.COLOR_TRANSPARENT);
        dc.fillCircle(x, y, r);
        dc.setPenWidth(s(4));
        dc.setColor(ring, Graphics.COLOR_TRANSPARENT);
        dc.drawArc(x, y, r - s(2), Graphics.ARC_CLOCKWISE, 160, 20);
        dc.setPenWidth(1);
        dc.setColor(WH, Graphics.COLOR_TRANSPARENT);

        if (t == 0) {
            // padlock (shackle raised when open)
            var col = locked ? WH : RED;
            dc.setColor(col, Graphics.COLOR_TRANSPARENT);
            dc.fillRoundedRectangle(x - s(13), y - s(3), s(26), s(20), s(4));
            var top = locked ? y - s(9) : y - s(15);
            dc.setPenWidth(s(5));
            dc.drawArc(x, top, s(9), Graphics.ARC_COUNTER_CLOCKWISE, 0, 180);
            dc.drawLine(x - s(9), top, x - s(9), y - s(2));
            if (locked) {
                dc.drawLine(x + s(9), top, x + s(9), y - s(2));
            }
            dc.setPenWidth(1);
        } else if (t == 1) {
            // fan
            dc.setColor(clim ? GREEN : WH, Graphics.COLOR_TRANSPARENT);
            for (var k = 0; k < 3; k++) {
                var a = Math.toRadians(90 + k * 120);
                dc.fillCircle(x + s(9) * Math.cos(a), y - s(9) * Math.sin(a), s(8));
            }
            dc.setColor(clim ? 0x0E3424 : BTN, Graphics.COLOR_TRANSPARENT);
            dc.fillCircle(x, y, s(4));
        } else if (t == 2 || t == 3) {
            // car seen from above, front or rear highlighted
            dc.setPenWidth(s(3));
            dc.drawRoundedRectangle(x - s(13), y - s(22), s(26), s(44), s(9));
            dc.setPenWidth(1);
            dc.setColor(RED, Graphics.COLOR_TRANSPARENT);
            if (t == 2) {
                dc.fillRoundedRectangle(x - s(13), y - s(22), s(26), s(14), s(8));
            } else {
                dc.fillRoundedRectangle(x - s(13), y + s(8), s(26), s(14), s(8));
            }
            dc.setColor(WH, Graphics.COLOR_TRANSPARENT);
            dc.setPenWidth(s(3));
            dc.drawLine(x - s(9), y - s(4), x + s(9), y - s(4));
            dc.setPenWidth(1);
        } else if (t == 4) {
            // light bulb with rays
            dc.fillCircle(x, y - s(3), s(11));
            dc.fillRectangle(x - s(6), y + s(8), s(12), s(7));
            dc.setPenWidth(s(3));
            for (var k = 0; k < 5; k++) {
                var a = Math.toRadians(30 + k * 30);
                dc.drawLine(x + s(17) * Math.cos(a), y - s(3) - s(17) * Math.sin(a),
                            x + s(23) * Math.cos(a), y - s(3) - s(23) * Math.sin(a));
            }
            dc.setPenWidth(1);
        } else if (t == 6) {
            // refresh: circular arrow
            dc.setPenWidth(s(4));
            dc.drawArc(x, y, s(15), Graphics.ARC_CLOCKWISE, 60, 120);
            dc.setPenWidth(1);
            var ax = x + s(15) * Math.cos(Math.toRadians(60));
            var ay = y - s(15) * Math.sin(Math.toRadians(60));
            dc.fillPolygon([[ax - s(9), ay - s(3)], [ax + s(5), ay - s(7)], [ax + s(1), ay + s(8)]]);
        } else {
            // horn / speaker
            dc.fillRectangle(x - s(16), y - s(6), s(8), s(12));
            dc.fillPolygon([[x - s(8), y - s(6)], [x + s(2), y - s(14)], [x + s(2), y + s(14)], [x - s(8), y + s(6)]]);
            dc.setPenWidth(s(3));
            dc.drawArc(x + s(2), y, s(8), Graphics.ARC_COUNTER_CLOCKWISE, -45, 45);
            dc.drawArc(x + s(2), y, s(14), Graphics.ARC_COUNTER_CLOCKWISE, -45, 45);
            dc.setPenWidth(1);
        }
    }
}
