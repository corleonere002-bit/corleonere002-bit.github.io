import Toybox.Application;
import Toybox.Background;
import Toybox.Communications;
import Toybox.Complications;
import Toybox.Lang;
import Toybox.System;
import Toybox.Time;

// Publishes the car battery as a complication (shown on Meridian) and the "car unlocked" alert.
(:background)
module CarShared {
    function publish(bat) {
        if (!(bat instanceof Lang.Number)) {
            return;
        }
        try {
            if (Toybox has :Complications) {
                Complications.updateComplication(0, {:value => bat.toString() + "%"});
            }
        } catch (e) {
        }
    }
}

// Background check every 30 / 60 minutes: battery, lock state, alert if left unlocked.
// Never wakes the car: when it sleeps, only the cheap state call is made.
(:background)
class CarBg extends System.ServiceDelegate {

    const AUTH_URL = "https://fleet-auth.prd.vn.cloud.tesla.com/oauth2/v3/token";

    function initialize() {
        ServiceDelegate.initialize();
    }

    function load(k) {
        try {
            return Application.Storage.getValue(k);
        } catch (e) {
            return null;
        }
    }

    function store(k, v) {
        try {
            Application.Storage.setValue(k, v);
        } catch (e) {
        }
    }

    function prop(k) {
        try {
            var v = Application.Properties.getValue(k);
            return (v instanceof Lang.String) ? v : "";
        } catch (e) {
            return "";
        }
    }

    function base() {
        var r = 0;
        try {
            r = Application.Properties.getValue("Region");
        } catch (e) {
            r = 0;
        }
        return (r == 1) ? "https://fleet-api.prd.na.vn.cloud.tesla.com" : "https://fleet-api.prd.eu.vn.cloud.tesla.com";
    }

    function opts() {
        return {
            :method => Communications.HTTP_REQUEST_METHOD_GET,
            :headers => { "Authorization" => "Bearer " + load("at") },
            :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
        };
    }

    function onTemporalEvent() as Void {
        var vin = load("vin");
        if (!(vin instanceof Lang.String) || prop("ClientId").length() == 0) {
            Background.exit(null);
            return;
        }
        var at = load("at");
        var exp = load("atExp");
        if ((at instanceof Lang.String) && (exp instanceof Lang.Number) && exp > Time.now().value() + 120) {
            getState();
            return;
        }
        var rt = load("rt");
        if (!(rt instanceof Lang.String)) {
            rt = prop("RefreshToken");
        }
        Communications.makeWebRequest(AUTH_URL, {
            "grant_type" => "refresh_token",
            "client_id" => prop("ClientId"),
            "refresh_token" => rt
        }, {
            :method => Communications.HTTP_REQUEST_METHOD_POST,
            :headers => { "Content-Type" => Communications.REQUEST_CONTENT_TYPE_URL_ENCODED },
            :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
        }, method(:onToken));
    }

    function onToken(code as Lang.Number, data as Lang.Dictionary or Lang.String or Null) as Void {
        if (code == 200 && data instanceof Lang.Dictionary && data["access_token"] instanceof Lang.String) {
            store("at", data["access_token"]);
            var e = data["expires_in"];
            store("atExp", Time.now().value() + ((e instanceof Lang.Number) ? e : 3600));
            if (data["refresh_token"] instanceof Lang.String) {
                store("rt", data["refresh_token"]);
            }
            getState();
            return;
        }
        Background.exit(null);
    }

    function getState() {
        Communications.makeWebRequest(base() + "/api/1/vehicles/" + load("vin"), null, opts(), method(:onState));
    }

    function onState(code as Lang.Number, data as Lang.Dictionary or Lang.String or Null) as Void {
        if (code != 200 || !(data instanceof Lang.Dictionary) || !(data["response"] instanceof Lang.Dictionary)) {
            Background.exit(null);
            return;
        }
        if ("online".equals(data["response"]["state"])) {
            getData("charge_state;vehicle_state");
        } else {
            // asleep: the car is parked and normally locked; keep the last battery value
            Background.exit(null);
        }
    }

    function getData(ep) {
        Communications.makeWebRequest(base() + "/api/1/vehicles/" + load("vin") + "/vehicle_data", {
            "endpoints" => ep
        }, opts(), (ep.find("vehicle_state") != null) ? method(:onData) : method(:onDataSmall));
    }

    function onDataSmall(code as Lang.Number, data as Lang.Dictionary or Lang.String or Null) as Void {
        handleData(code, data, false);
    }

    function onData(code as Lang.Number, data as Lang.Dictionary or Lang.String or Null) as Void {
        if (code == -402 || code == -403) {
            getData("charge_state");     // answer too big for the background: battery only
            return;
        }
        handleData(code, data, true);
    }

    function handleData(code, data, withLock) {
        if (code != 200 || !(data instanceof Lang.Dictionary) || !(data["response"] instanceof Lang.Dictionary)) {
            Background.exit(null);
            return;
        }
        var r = data["response"];
        var c = load("cache");
        if (!(c instanceof Lang.Dictionary)) {
            c = {};
        }
        var cs = r["charge_state"];
        if (cs instanceof Lang.Dictionary) {
            if (cs["battery_level"] != null) { c.put("bat", cs["battery_level"].toNumber()); }
            if (cs["battery_range"] != null) { c.put("rng", cs["battery_range"].toFloat()); }
            if (cs["charging_state"] instanceof Lang.String) { c.put("chg", cs["charging_state"]); }
        }
        var alert = null;
        var vs = r["vehicle_state"];
        if (withLock && vs instanceof Lang.Dictionary && vs["locked"] != null) {
            var locked = (vs["locked"] == true);
            c.put("lock", locked);
            if (locked) {
                store("ulAlerted", false);
            } else if (wantsAlert() && load("ulAlerted") != true) {
                // unlocked on two checks in a row -> remind once
                if (load("ulSeen") == true) {
                    alert = "Your car is unlocked";
                    store("ulAlerted", true);
                }
            }
            store("ulSeen", !locked);
        }
        c.put("t", Time.now().value());
        store("cache", c);
        CarShared.publish(c["bat"]);
        if (alert != null) {
            try {
                Background.requestApplicationWake(alert);
            } catch (e) {
            }
        }
        Background.exit(null);
    }

    function wantsAlert() {
        try {
            return Application.Properties.getValue("UnlockAlert") != false;
        } catch (e) {
            return true;
        }
    }
}
