import Toybox.Application;
import Toybox.Communications;
import Toybox.Cryptography;
import Toybox.Lang;
import Toybox.System;
import Toybox.Time;
import Toybox.Timer;
import Toybox.WatchUi;

enum {
    A_REFRESH = 0,
    A_LOCK = 1,
    A_UNLOCK = 2,
    A_CLIMATE_ON = 3,
    A_CLIMATE_OFF = 4,
    A_WAKE = 5,
    A_FRUNK = 6,
    A_TRUNK = 7,
    A_FLASH = 8,
    A_HONK = 9
}

// Talks to Tesla Fleet API through the phone: token refresh, vehicle data, wake, signed commands.
class CarApi {

    const AUTH_URL = "https://fleet-auth.prd.vn.cloud.tesla.com/oauth2/v3/token";

    var mBusy = false;
    var mStatus = "";
    var mError = false;

    hidden var mAction = A_REFRESH;
    hidden var mOnline = false;
    hidden var mCmdDone = false;
    hidden var mDataDone = false;
    hidden var mTries = 0;
    hidden var mRetry = 0;
    hidden var mAuthRetry = 0;
    hidden var mTimer = null;
    hidden var mVin = null;

    // session state for the current command
    hidden var mK = null;
    hidden var mEpoch = null;
    hidden var mCounter = 0;
    hidden var mClock = 0;
    hidden var mRecv = 0;
    hidden var mAddr = null;
    hidden var mUuid = null;
    hidden var mPub65 = null;
    hidden var mPair = null;
    hidden var mCal = null;
    hidden var mDataEndpoints = "charge_state;climate_state;vehicle_state";

    function initialize() {
        mTimer = new Timer.Timer();
    }

    // ---------------------------------------------------------------- settings
    function prop(key) {
        try {
            var v = Application.Properties.getValue(key);
            return (v instanceof Lang.String) ? v : "";
        } catch (e) {
            return "";
        }
    }

    function base() {
        var r = 0;
        try {
            r = Application.Properties.getValue("Region");
        } catch (e) {
            r = 0;
        }
        return (r == 1) ? "https://fleet-api.prd.na.vn.cloud.tesla.com" : "https://fleet-api.prd.eu.vn.cloud.tesla.com";
    }

    function isSetUp() {
        return prop("ClientId").length() > 0 && prop("RefreshToken").length() > 0 && prop("PrivateKey").length() == 64;
    }

    function store(key, val) {
        try {
            if (val == null) {
                Application.Storage.deleteValue(key);
                return;
            }
            Application.Storage.setValue(key, val);
        } catch (e) {
        }
    }

    function load(key) {
        try {
            return Application.Storage.getValue(key);
        } catch (e) {
            return null;
        }
    }

    // ---------------------------------------------------------------- public
    function start(action) {
        if (mBusy) {
            return;
        }
        if (!isSetUp()) {
            setStatus("Set up in Connect IQ app", true);
            return;
        }
        mAction = action;
        mBusy = true;
        mError = false;
        mOnline = false;
        mCmdDone = (action == A_REFRESH || action == A_WAKE);
        mDataDone = false;
        mRetry = 0;
        mAuthRetry = 0;
        mDataEndpoints = "charge_state;climate_state;vehicle_state";
        setStatus("Connecting...", false);
        advance();
    }

    hidden function setStatus(s, err) {
        mStatus = s;
        mError = err;
        WatchUi.requestUpdate();
    }

    hidden function fail(s) {
        mBusy = false;
        setStatus(s, true);
    }

    hidden function done(s) {
        mBusy = false;
        setStatus(s, false);
    }

    hidden function advance() {
        if (!tokenValid()) {
            refreshToken();
            return;
        }
        if (mVin == null) {
            var v = load("vin");
            if (v instanceof Lang.String && v.length() == 17) {
                mVin = v;
            } else {
                getVehicles();
                return;
            }
        }
        if (!mCmdDone) {
            if (!mOnline) {
                wake();
                return;
            }
            hello();
            return;
        }
        if (mAction == A_WAKE && !mOnline) {
            wake();
            return;
        }
        if (!mDataDone) {
            if (mOnline) {
                getData();
            } else {
                getState();
            }
            return;
        }
        if (mAction == A_REFRESH || mAction == A_WAKE) {
            done("Updated " + clock());
        } else {
            done(doneText() + " " + clock());
        }
    }

    // a 401 answer: drop the access token and sign in again (once)
    hidden function reauth() {
        store("at", null);
        mAuthRetry++;
        if (mAuthRetry > 1) {
            fail("Login expired - redo token step");
            return;
        }
        advance();
    }

    function clock() {
        var t = System.getClockTime();
        return t.hour.format("%02d") + ":" + t.min.format("%02d");
    }

    hidden function headers() {
        return {
            "Authorization" => "Bearer " + load("at"),
            "Content-Type" => Communications.REQUEST_CONTENT_TYPE_JSON
        };
    }

    hidden function httpError(code) {
        if (code == -104 || code == -2) { return "Phone not connected"; }
        if (code == -300) { return "No answer (timeout)"; }
        if (code == -402 || code == -403) { return "Answer too large"; }
        if (code == 401) { return "Login expired"; }
        if (code == 403) { return "No permission (scopes)"; }
        if (code == 408) { return "Car asleep / offline"; }
        if (code == 412) { return "App not registered (step 3)"; }
        if (code == 429) { return "Too many requests, wait"; }
        return "Error " + code.toString();
    }

    // ---------------------------------------------------------------- token
    hidden function tokenValid() {
        var at = load("at");
        var exp = load("atExp");
        return (at instanceof Lang.String) && (exp instanceof Lang.Number) && exp > Time.now().value() + 120;
    }

    hidden function currentRefresh() {
        var fromSettings = prop("RefreshToken");
        var seen = load("rtSeen");
        var rt = load("rt");
        // a newly pasted token in settings always wins
        if (!(seen instanceof Lang.String) || !seen.equals(fromSettings) || !(rt instanceof Lang.String)) {
            store("rtSeen", fromSettings);
            store("rt", fromSettings);
            return fromSettings;
        }
        return rt;
    }

    hidden function refreshToken() {
        setStatus("Signing in...", false);
        Communications.makeWebRequest(AUTH_URL, {
            "grant_type" => "refresh_token",
            "client_id" => prop("ClientId"),
            "refresh_token" => currentRefresh()
        }, {
            :method => Communications.HTTP_REQUEST_METHOD_POST,
            :headers => { "Content-Type" => Communications.REQUEST_CONTENT_TYPE_URL_ENCODED },
            :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
        }, method(:onToken));
    }

    function onToken(code as Lang.Number, data as Lang.Dictionary or Lang.String or Null) as Void {
        if (code == 200 && data instanceof Lang.Dictionary && data["access_token"] instanceof Lang.String) {
            store("at", data["access_token"]);
            var exp = data["expires_in"];
            store("atExp", Time.now().value() + ((exp instanceof Lang.Number) ? exp : 3600));
            if (data["refresh_token"] instanceof Lang.String) {
                store("rt", data["refresh_token"]);
            }
            advance();
            return;
        }
        if (code == 400 || code == 401) {
            fail("Token refused - redo token step");
            return;
        }
        fail(httpError(code));
    }

    // ---------------------------------------------------------------- vehicles / state
    hidden function getVehicles() {
        setStatus("Finding your car...", false);
        Communications.makeWebRequest(base() + "/api/1/vehicles", null, {
            :method => Communications.HTTP_REQUEST_METHOD_GET,
            :headers => headers(),
            :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
        }, method(:onVehicles));
    }

    function onVehicles(code as Lang.Number, data as Lang.Dictionary or Lang.String or Null) as Void {
        if (code == 401) { reauth(); return; }
        if (code != 200 || !(data instanceof Lang.Dictionary)) { fail(httpError(code)); return; }
        var list = data["response"];
        if (!(list instanceof Lang.Array) || list.size() == 0) { fail("No car on this account"); return; }
        var car = list[0];
        if (!(car instanceof Lang.Dictionary) || !(car["vin"] instanceof Lang.String)) { fail("No car on this account"); return; }
        mVin = car["vin"];
        store("vin", mVin);
        if (car["display_name"] instanceof Lang.String) {
            updateCache({"name" => car["display_name"]});
        }
        mOnline = "online".equals(car["state"]);
        advance();
    }

    hidden function getState() {
        Communications.makeWebRequest(base() + "/api/1/vehicles/" + mVin, null, {
            :method => Communications.HTTP_REQUEST_METHOD_GET,
            :headers => headers(),
            :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
        }, method(:onState));
    }

    function onState(code as Lang.Number, data as Lang.Dictionary or Lang.String or Null) as Void {
        if (code == 401) { reauth(); return; }
        if (code != 200 || !(data instanceof Lang.Dictionary) || !(data["response"] instanceof Lang.Dictionary)) {
            fail(httpError(code));
            return;
        }
        var st = data["response"]["state"];
        mOnline = "online".equals(st);
        if (mOnline) {
            advance();
        } else {
            updateCache({"state" => (st instanceof Lang.String) ? st : "asleep"});
            mDataDone = true;
            done("Car asleep - Wake & refresh");
        }
    }

    hidden function getData() {
        setStatus("Reading car...", false);
        Communications.makeWebRequest(base() + "/api/1/vehicles/" + mVin + "/vehicle_data", {
            "endpoints" => mDataEndpoints
        }, {
            :method => Communications.HTTP_REQUEST_METHOD_GET,
            :headers => headers(),
            :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
        }, method(:onData));
    }

    function onData(code as Lang.Number, data as Lang.Dictionary or Lang.String or Null) as Void {
        if (code == 401) { reauth(); return; }
        if ((code == -402 || code == -403) && mDataEndpoints.find("vehicle_state") != null) {
            mDataEndpoints = "charge_state;climate_state";
            getData();
            return;
        }
        if (code == 408) {
            mOnline = false;
            mDataDone = true;
            updateCache({"state" => "asleep"});
            done("Car asleep - Wake & refresh");
            return;
        }
        if (code != 200 || !(data instanceof Lang.Dictionary) || !(data["response"] instanceof Lang.Dictionary)) {
            fail(httpError(code));
            return;
        }
        var r = data["response"];
        var c = {"state" => "online", "t" => Time.now().value()};
        if (r["display_name"] instanceof Lang.String) { c.put("name", r["display_name"]); }
        var cs = r["charge_state"];
        if (cs instanceof Lang.Dictionary) {
            if (cs["battery_level"] != null) { c.put("bat", cs["battery_level"].toNumber()); }
            if (cs["battery_range"] != null) { c.put("rng", cs["battery_range"].toFloat()); }
            if (cs["charging_state"] instanceof Lang.String) { c.put("chg", cs["charging_state"]); }
        }
        var cl = r["climate_state"];
        if (cl instanceof Lang.Dictionary) {
            if (cl["is_climate_on"] != null) { c.put("clim", cl["is_climate_on"] == true); }
            if (cl["inside_temp"] != null) { c.put("in", cl["inside_temp"].toFloat()); }
        }
        var vs = r["vehicle_state"];
        if (vs instanceof Lang.Dictionary && vs["locked"] != null) {
            c.put("lock", vs["locked"] == true);
        }
        updateCache(c);
        mDataDone = true;
        advance();
    }

    function updateCache(vals) {
        var c = load("cache");
        if (!(c instanceof Lang.Dictionary)) {
            c = {};
        }
        var keys = vals.keys();
        for (var i = 0; i < keys.size(); i++) {
            c.put(keys[i], vals[keys[i]]);
        }
        store("cache", c);
        CarShared.publish(c["bat"]);
    }

    // ---------------------------------------------------------------- wake
    hidden function wake() {
        setStatus("Waking car...", false);
        mTries = 0;
        Communications.makeWebRequest(base() + "/api/1/vehicles/" + mVin + "/wake_up", {}, {
            :method => Communications.HTTP_REQUEST_METHOD_POST,
            :headers => headers(),
            :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
        }, method(:onWake));
    }

    function onWake(code as Lang.Number, data as Lang.Dictionary or Lang.String or Null) as Void {
        if (code == 401) { reauth(); return; }
        if (code == 200 && data instanceof Lang.Dictionary && data["response"] instanceof Lang.Dictionary
            && "online".equals(data["response"]["state"])) {
            mOnline = true;
            advance();
            return;
        }
        if (code != 200 && code != 408) {
            fail(httpError(code));
            return;
        }
        mTimer.start(method(:poll), 3000, false);
    }

    function poll() as Void {
        mTries++;
        if (mTries > 15) {
            fail("Car did not wake up");
            return;
        }
        setStatus("Waking car... " + mTries.toString(), false);
        Communications.makeWebRequest(base() + "/api/1/vehicles/" + mVin, null, {
            :method => Communications.HTTP_REQUEST_METHOD_GET,
            :headers => headers(),
            :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
        }, method(:onPoll));
    }

    function onPoll(code as Lang.Number, data as Lang.Dictionary or Lang.String or Null) as Void {
        if (code == 200 && data instanceof Lang.Dictionary && data["response"] instanceof Lang.Dictionary
            && "online".equals(data["response"]["state"])) {
            mOnline = true;
            advance();
            return;
        }
        if (code != 200 && code != 408) {
            fail(httpError(code));
            return;
        }
        mTimer.start(method(:poll), 3000, false);
    }

    // ---------------------------------------------------------------- signed commands
    hidden function domain() {
        return (mAction == A_LOCK || mAction == A_UNLOCK || mAction == A_FRUNK || mAction == A_TRUNK)
            ? CarProto.DOMAIN_VCSEC : CarProto.DOMAIN_INFO;
    }

    hidden function payload() {
        if (mAction == A_LOCK) { return CarProto.pLock(); }
        if (mAction == A_UNLOCK) { return CarProto.pUnlock(); }
        if (mAction == A_FRUNK) { return CarProto.pClosure(6); }
        if (mAction == A_TRUNK) { return CarProto.pClosure(5); }
        if (mAction == A_FLASH) { return CarProto.pAction(26); }
        if (mAction == A_HONK) { return CarProto.pAction(27); }
        return CarProto.pClimate(mAction == A_CLIMATE_ON);
    }

    hidden function keys() {
        if (mPub65 != null) {
            return true;
        }
        mCal = CarProto.calibrate();
        if (mCal == null) {
            return false;
        }
        var priv = null;
        try {
            priv = CarProto.hex(prop("PrivateKey").toLower());
        } catch (e) {
            priv = null;
        }
        if (priv == null || priv.size() != 32) {
            return false;
        }
        mPair = CarProto.makePair(priv, mCal[0]);
        if (mPair == null) {
            return false;
        }
        var xy = CarProto.pubFromWatch(mPair.getPublicKey().getBytes(), mCal[3]);
        if (xy == null) {
            return false;
        }
        mPub65 = CarProto.cat(CarProto.one(4), xy);
        return true;
    }

    hidden function signedPost(msg, cb) {
        Communications.makeWebRequest(base() + "/api/1/vehicles/" + mVin + "/signed_command", {
            "routable_message" => CarProto.toB64(msg)
        }, {
            :method => Communications.HTTP_REQUEST_METHOD_POST,
            :headers => headers(),
            :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
        }, cb);
    }

    hidden function hello() {
        if (!keys()) {
            fail(mCal == null ? "Crypto self-test failed" : "Bad private key");
            return;
        }
        setStatus("Securing link...", false);
        mAddr = Cryptography.randomBytes(16);
        mUuid = Cryptography.randomBytes(16);
        signedPost(CarProto.sessionRequest(domain(), mPub65, mAddr, mUuid), method(:onHello));
    }

    hidden function decodeResponse(code, data) {
        if (code != 200 || !(data instanceof Lang.Dictionary) || !(data["response"] instanceof Lang.String)) {
            return null;
        }
        try {
            return CarProto.parse(CarProto.fromB64(data["response"]));
        } catch (e) {
            return null;
        }
    }

    // Reads session info from a vehicle message; returns true if valid
    hidden function applySession(resp) {
        var info = CarProto.getB(resp, 15);
        if (info == null) {
            return false;
        }
        var si = CarProto.parse(info);
        if (CarProto.getN(si, 5) == 1) {
            return false;    // key not on whitelist
        }
        var vpub = CarProto.getB(si, 2);
        if (vpub == null || vpub.size() != 65) {
            return false;
        }
        var sec = CarProto.ecdh(mPair, vpub.slice(1, 65), mCal[1]);
        var sx = CarProto.secretX(sec, mCal[2]);
        if (sx == null) {
            return false;
        }
        var k = CarProto.sha1(sx).slice(0, 16);
        var sd = CarProto.parse(CarProto.getB(resp, 13));
        var tagMsg = CarProto.parse(CarProto.getB(sd, 6));
        var tag = CarProto.getB(tagMsg, 1);
        var challenge = CarProto.getB(resp, 50);
        if (challenge == null) {
            challenge = mUuid;
        }
        if (tag == null || !CarProto.sessionTagOk(k, CarProto.text(mVin), challenge, info, tag)) {
            return false;
        }
        mK = k;
        mEpoch = CarProto.getB(si, 3);
        if (mEpoch == null) {
            mEpoch = []b;
        }
        mCounter = CarProto.getN(si, 1);
        mClock = CarProto.getN(si, 4);
        mRecv = Time.now().value();
        return true;
    }

    function onHello(code as Lang.Number, data as Lang.Dictionary or Lang.String or Null) as Void {
        if (code == 401) { reauth(); return; }
        if (code == 408) { mOnline = false; advance(); return; }
        var resp = decodeResponse(code, data);
        if (resp == null) {
            fail(httpError(code));
            return;
        }
        if (!applySession(resp)) {
            var st = CarProto.parse(CarProto.getB(resp, 12));
            var f = CarProto.getN(st, 2);
            var si = CarProto.parse(CarProto.getB(resp, 15));
            if (f == 3 || CarProto.getN(si, 5) == 1) {
                fail("Key not added to car (step 5)");
            } else if (f != 0) {
                fail(faultText(f));
            } else {
                fail("Secure link failed");
            }
            return;
        }
        sendCommand();
    }

    hidden function sendCommand() {
        setStatus(actionText() + "...", false);
        mCounter++;
        var expires = mClock + (Time.now().value() - mRecv) + CarProto.TTL;
        var r = CarProto.command(domain(), CarProto.text(mVin), mK, mPub65, mEpoch, mCounter, expires,
            payload(), mAddr, Cryptography.randomBytes(16));
        signedPost(r[0], method(:onCommand));
    }

    function onCommand(code as Lang.Number, data as Lang.Dictionary or Lang.String or Null) as Void {
        if (code == 401) { store("at", null); fail("Login expired, try again"); return; }
        if (code == 408) { fail("Car went to sleep, try again"); return; }
        var resp = decodeResponse(code, data);
        if (resp == null) {
            fail(httpError(code));
            return;
        }
        var st = CarProto.parse(CarProto.getB(resp, 12));
        var op = CarProto.getN(st, 1);
        var f = CarProto.getN(st, 2);
        if (f != 0) {
            // out of sync: the car sends fresh session info, update and resend once
            if (mRetry == 0 && (f == 5 || f == 6 || f == 15 || f == 17 || f == 26) && applySession(resp)) {
                mRetry++;
                sendCommand();
                return;
            }
            fail(faultText(f));
            return;
        }
        if (op == 2) {
            fail("Car refused the command");
            return;
        }
        // read the result inside the (encrypted) payload
        var plain = CarProto.getB(resp, 10);
        var sd = CarProto.parse(CarProto.getB(resp, 13));
        var g = CarProto.parse(CarProto.getB(sd, 9));
        if (CarProto.getB(g, 1) != null) {
            plain = CarProto.gcmDecrypt(mK, CarProto.getB(g, 1), plain);
        }
        if (plain != null && plain.size() > 0) {
            var p = CarProto.parse(plain);
            if (domain() == CarProto.DOMAIN_INFO) {
                var ast = CarProto.parse(CarProto.getB(p, 1));
                if (CarProto.getN(ast, 1) == 1) {
                    fail("Car refused the command");
                    return;
                }
            } else {
                var cs = CarProto.parse(CarProto.getB(p, 4));
                if (CarProto.getN(cs, 1) == 2) {
                    fail("Car refused the command");
                    return;
                }
            }
        }
        // success: show it right away, then read fresh data
        if (mAction == A_LOCK) { updateCache({"lock" => true}); }
        if (mAction == A_UNLOCK) { updateCache({"lock" => false}); }
        if (mAction == A_CLIMATE_ON) { updateCache({"clim" => true}); }
        if (mAction == A_CLIMATE_OFF) { updateCache({"clim" => false}); }
        mCmdDone = true;
        mDataDone = false;
        setStatus(doneText() + " " + clock(), false);
        mTimer.start(method(:afterCommand), 2500, false);
    }

    function afterCommand() as Void {
        advance();
    }

    hidden function actionText() {
        if (mAction == A_LOCK) { return "Locking"; }
        if (mAction == A_UNLOCK) { return "Unlocking"; }
        if (mAction == A_CLIMATE_ON) { return "Starting climate"; }
        if (mAction == A_FRUNK) { return "Opening frunk"; }
        if (mAction == A_TRUNK) { return "Opening trunk"; }
        if (mAction == A_FLASH) { return "Flashing lights"; }
        if (mAction == A_HONK) { return "Honking"; }
        return "Stopping climate";
    }

    hidden function doneText() {
        if (mAction == A_LOCK) { return "Locked"; }
        if (mAction == A_UNLOCK) { return "Unlocked"; }
        if (mAction == A_CLIMATE_ON) { return "Climate on"; }
        if (mAction == A_FRUNK) { return "Frunk open"; }
        if (mAction == A_TRUNK) { return "Trunk moved"; }
        if (mAction == A_FLASH) { return "Lights flashed"; }
        if (mAction == A_HONK) { return "Honked"; }
        return "Climate off";
    }

    hidden function faultText(f) {
        if (f == 1) { return "Car busy, try again"; }
        if (f == 2) { return "Car timeout, try again"; }
        if (f == 3) { return "Key not added to car (step 5)"; }
        if (f == 4) { return "Key disabled in car"; }
        if (f == 7) { return "Not allowed now"; }
        if (f == 11) { return "Car still booting, retry"; }
        if (f == 21) { return "Mobile access is off in car"; }
        if (f == 28) { return "Car needs newer protocol"; }
        return "Car error " + f.toString();
    }
}
