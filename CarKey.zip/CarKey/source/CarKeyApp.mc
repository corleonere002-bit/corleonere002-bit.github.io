import Toybox.Application;
import Toybox.Background;
import Toybox.Lang;
import Toybox.System;
import Toybox.Time;
import Toybox.WatchUi;

(:glance, :background)
class CarKeyApp extends Application.AppBase {

    var mApi = null;
    var mView = null;

    function initialize() {
        AppBase.initialize();
    }

    function onStart(state) {
    }

    function onStop(state) {
    }

    function getInitialView() {
        scheduleChecks();
        mApi = new CarApi();
        mView = new CarView(mApi);
        return [ mView, new CarDelegate(mApi, mView) ];
    }

    function getGlanceView() {
        return [ new CarGlance() ];
    }

    function getServiceDelegate() {
        return [ new CarBg() ];
    }

    function onBackgroundData(data) {
        WatchUi.requestUpdate();
    }

    function onSettingsChanged() {
        scheduleChecks();
        WatchUi.requestUpdate();
    }

    // background check: 0 = off, 1 = every 30 min, 2 = every 60 min
    function scheduleChecks() {
        if (!(Toybox.System has :ServiceDelegate)) {
            return;
        }
        var m = 2;
        try {
            var v = Application.Properties.getValue("BgCheck");
            if (v instanceof Lang.Number) {
                m = v;
            }
        } catch (e) {
            m = 2;
        }
        try {
            if (m == 0) {
                Background.deleteTemporalEvent();
            } else {
                Background.registerForTemporalEvent(new Time.Duration((m == 1) ? 30 * 60 : 60 * 60));
            }
        } catch (e) {
        }
    }
}
