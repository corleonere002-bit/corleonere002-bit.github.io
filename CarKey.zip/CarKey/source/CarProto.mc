import Toybox.Application;
import Toybox.Cryptography;
import Toybox.Lang;
import Toybox.StringUtil;

// Tesla Vehicle Command Protocol (Fleet API, HMAC-SHA256 authorization).
// Hand-rolled protobuf + metadata, mirrors teslamotors/vehicle-command.
module CarProto {

    const DOMAIN_VCSEC = 2;
    const DOMAIN_INFO = 3;
    const FLAGS = 2;                // 1 << FLAG_ENCRYPT_RESPONSE
    const TTL = 15;                 // seconds a command stays valid

    // ---------------------------------------------------------------- bytes helpers
    function cat(a, b) {
        var r = a.slice(0, null);
        r.addAll(b);
        return r;
    }

    function one(n) {
        var b = new [1]b;
        b[0] = n & 0xFF;
        return b;
    }

    function u32be(n) {
        var b = new [4]b;
        b[0] = (n >> 24) & 0xFF;
        b[1] = (n >> 16) & 0xFF;
        b[2] = (n >> 8) & 0xFF;
        b[3] = n & 0xFF;
        return b;
    }

    function u32le(n) {
        var b = new [4]b;
        b[0] = n & 0xFF;
        b[1] = (n >> 8) & 0xFF;
        b[2] = (n >> 16) & 0xFF;
        b[3] = (n >> 24) & 0xFF;
        return b;
    }

    function rev(a) {
        var n = a.size();
        var r = new [n]b;
        for (var i = 0; i < n; i++) {
            r[i] = a[n - 1 - i];
        }
        return r;
    }

    function eq(a, b) {
        if (a == null || b == null || a.size() != b.size()) {
            return false;
        }
        var d = 0;
        for (var i = 0; i < a.size(); i++) {
            d = d | (a[i] ^ b[i]);
        }
        return d == 0;
    }

    function hex(s) {
        return StringUtil.convertEncodedString(s, {
            :fromRepresentation => StringUtil.REPRESENTATION_STRING_HEX,
            :toRepresentation => StringUtil.REPRESENTATION_BYTE_ARRAY
        });
    }

    function text(s) {
        return StringUtil.convertEncodedString(s, {
            :fromRepresentation => StringUtil.REPRESENTATION_STRING_PLAIN_TEXT,
            :toRepresentation => StringUtil.REPRESENTATION_BYTE_ARRAY
        });
    }

    function toB64(b) {
        return StringUtil.convertEncodedString(b, {
            :fromRepresentation => StringUtil.REPRESENTATION_BYTE_ARRAY,
            :toRepresentation => StringUtil.REPRESENTATION_STRING_BASE64
        });
    }

    function fromB64(s) {
        return StringUtil.convertEncodedString(s, {
            :fromRepresentation => StringUtil.REPRESENTATION_STRING_BASE64,
            :toRepresentation => StringUtil.REPRESENTATION_BYTE_ARRAY
        });
    }

    // ---------------------------------------------------------------- protobuf writer
    function varint(n) {
        var b = []b;
        while (true) {
            var x = n & 0x7F;
            n = n >> 7;
            if (n != 0) {
                b.add(x | 0x80);
            } else {
                b.add(x);
                return b;
            }
        }
        return b;
    }

    function fVarint(field, n) {
        return cat(varint(field << 3), varint(n));
    }

    function fBytes(field, data) {
        var r = varint((field << 3) | 2);
        r.addAll(varint(data.size()));
        r.addAll(data);
        return r;
    }

    function fFixed32(field, n) {
        return cat(varint((field << 3) | 5), u32le(n));
    }

    // ---------------------------------------------------------------- protobuf reader
    // returns { field => value } (first occurrence); bytes for wire type 2, Number otherwise
    function parse(b) {
        var out = {};
        if (b == null) {
            return out;
        }
        var i = 0;
        var n = b.size();
        while (i < n) {
            var key = 0;
            var sh = 0;
            while (i < n) {
                var c = b[i];
                i++;
                key = key | ((c & 0x7F) << sh);
                sh += 7;
                if (c < 0x80) { break; }
            }
            var field = key >> 3;
            var wt = key & 7;
            var v = null;
            if (wt == 0) {
                v = 0;
                sh = 0;
                while (i < n) {
                    var c = b[i];
                    i++;
                    if (sh < 31) {
                        v = v | ((c & 0x7F) << sh);
                    }
                    sh += 7;
                    if (c < 0x80) { break; }
                }
            } else if (wt == 2) {
                var ln = 0;
                sh = 0;
                while (i < n) {
                    var c = b[i];
                    i++;
                    ln = ln | ((c & 0x7F) << sh);
                    sh += 7;
                    if (c < 0x80) { break; }
                }
                if (i + ln > n) {
                    return out;
                }
                v = b.slice(i, i + ln);
                i += ln;
            } else if (wt == 5) {
                if (i + 4 > n) { return out; }
                v = b[i] | (b[i + 1] << 8) | (b[i + 2] << 16) | (b[i + 3] << 24);
                i += 4;
            } else if (wt == 1) {
                if (i + 8 > n) { return out; }
                v = b[i] | (b[i + 1] << 8) | (b[i + 2] << 16) | (b[i + 3] << 24);
                i += 8;
            } else {
                return out;
            }
            if (!out.hasKey(field)) {
                out.put(field, v);
            }
        }
        return out;
    }

    function getB(d, field) {
        var v = d.get(field);
        return (v instanceof Lang.ByteArray) ? v : null;
    }

    function getN(d, field) {
        var v = d.get(field);
        return (v instanceof Lang.Number) ? v : 0;
    }

    // ---------------------------------------------------------------- crypto
    function hmac(key, data) {
        var h = new Cryptography.HashBasedMessageAuthenticationCode({
            :algorithm => Cryptography.HASH_SHA256,
            :key => key
        });
        h.update(data);
        return h.digest();
    }

    function sha1(data) {
        var h = new Cryptography.Hash({:algorithm => Cryptography.HASH_SHA1});
        h.update(data);
        return h.digest();
    }

    function tlv(tag, val) {
        var r = one(tag);
        r.add(val.size());
        r.addAll(val);
        return r;
    }

    // ----- Garmin key format calibration (byte order is not documented clearly).
    // Uses the published Tesla test vectors (protocol.md) to find which byte order
    // this watch expects. Result: [privFmt, inFmt, secFmt, outFmt]
    const T_PRIV = "2538cdc29a97c19c1e99a637d6cf4f8c970c118b56ede1e6323e6d162c4b30db";
    const T_PUB = "b2b6bc68c2da0665ce656815594996c62394edd8bea905fe781a754fe6a845a714330902f225e9269d466e05b349981fda9d85cc23c6fb444aa73b629105dc6e";
    const T_VEH = "c7a1f47138486aa4729971494878d33b1a24e39571f748a6e16c5955b3d877d3a6aaa0e955166474af5d32c410f439a2234137ad1bb085fd4e8813c958f11d97";
    const T_K = "1b2fce19967b79db696f909cff89ea9a";

    // xy = X(32, big endian) || Y(32, big endian) -> watch format
    function pubToWatch(xy, fmt) {
        var x = xy.slice(0, 32);
        var y = xy.slice(32, 64);
        if (fmt == 0) { return cat(rev(x), rev(y)); }
        if (fmt == 1) { return xy; }
        if (fmt == 2) { return cat(one(4), xy); }
        return cat(one(4), cat(rev(x), rev(y)));
    }

    // watch format -> X||Y big endian (64 bytes) or null
    function pubFromWatch(b, fmt) {
        if (b == null) { return null; }
        if (b.size() == 65) { b = b.slice(1, 65); }
        if (b.size() != 64) { return null; }
        if (fmt == 0 || fmt == 3) {
            return cat(rev(b.slice(0, 32)), rev(b.slice(32, 64)));
        }
        return b;
    }

    function privToWatch(be, fmt) {
        return (fmt == 0) ? rev(be) : be;
    }

    function secretX(sec, fmt) {
        if (sec == null) { return null; }
        var x = sec;
        if (sec.size() >= 64) {
            x = (fmt == 0) ? sec.slice(0, 32) : sec.slice(0, 32);
        }
        if (x.size() != 32) { return null; }
        return (fmt == 0) ? rev(x) : x;
    }

    function makePair(privBe, fmt) {
        try {
            return new Cryptography.KeyPair({
                :algorithm => Cryptography.KEY_PAIR_ELLIPTIC_CURVE_SECP256R1,
                :privateKey => privToWatch(privBe, fmt)
            });
        } catch (e) {
            return null;
        }
    }

    // untyped on purpose: the SDK declares createPublicKey's first parameter with the wrong enum type
    function curve() {
        return 1;    // KEY_PAIR_ELLIPTIC_CURVE_SECP256R1
    }

    function ecdh(pair, vehXY, inFmt) {
        try {
            var pub = Cryptography.createPublicKey(curve(), pubToWatch(vehXY, inFmt));
            var ka = new Cryptography.KeyAgreement({
                :protocol => Cryptography.KEY_AGREEMENT_ECDH,
                :privateKey => pair.getPrivateKey()
            });
            ka.addKey(pub);
            return ka.generateSecret();
        } catch (e) {
            return null;
        }
    }

    function calibrate() {
        var cal = null;
        try {
            cal = Application.Storage.getValue("cal");
        } catch (e) {
            cal = null;
        }
        if (cal instanceof Lang.Array && cal.size() == 4) {
            return cal;
        }
        var priv = hex(T_PRIV);
        var veh = hex(T_VEH);
        var k = hex(T_K);
        var tpub = hex(T_PUB);
        for (var pf = 0; pf < 2; pf++) {
            var pair = makePair(priv, pf);
            if (pair == null) { continue; }
            // how does getBytes() return our public key?
            var outFmt = -1;
            try {
                var gb = pair.getPublicKey().getBytes();
                if (eq(pubFromWatch(gb, 0), tpub)) { outFmt = 0; }
                else if (eq(pubFromWatch(gb, 1), tpub)) { outFmt = 1; }
            } catch (e) {
            }
            if (outFmt < 0) { continue; }
            for (var inf = 0; inf < 4; inf++) {
                var sec = ecdh(pair, veh, inf);
                if (sec == null) { continue; }
                for (var sf = 0; sf < 2; sf++) {
                    var sx = secretX(sec, sf);
                    if (sx != null && eq(sha1(sx).slice(0, 16), k)) {
                        cal = [pf, inf, sf, outFmt];
                        Application.Storage.setValue("cal", cal);
                        return cal;
                    }
                }
            }
        }
        return null;
    }

    // ---------------------------------------------------------------- messages
    function sessionRequest(domain, pub65, addr, uuid) {
        var m = fBytes(6, fVarint(1, domain));
        m.addAll(fBytes(7, fBytes(2, addr)));
        m.addAll(fBytes(14, fBytes(1, pub65)));
        m.addAll(fBytes(51, uuid));
        return m;
    }

    function sessionTagOk(k, vin, challenge, info, tag) {
        var key = hmac(k, text("session info"));
        var meta = tlv(0, one(6));
        meta.addAll(tlv(2, vin));
        meta.addAll(tlv(6, challenge));
        meta.add(0xFF);
        meta.addAll(info);
        return eq(hmac(key, meta), tag);
    }

    // returns [message bytes, tag]
    function command(domain, vin, k, pub65, epoch, counter, expires, payload, addr, uuid) {
        var meta = tlv(0, one(8));
        meta.addAll(tlv(1, one(domain)));
        meta.addAll(tlv(2, vin));
        meta.addAll(tlv(3, epoch));
        meta.addAll(tlv(4, u32be(expires)));
        meta.addAll(tlv(5, u32be(counter)));
        meta.addAll(tlv(7, u32be(FLAGS)));
        meta.add(0xFF);
        meta.addAll(payload);
        var tag = hmac(hmac(k, text("authenticated command")), meta);

        var hd = fBytes(1, epoch);
        hd.addAll(fVarint(2, counter));
        hd.addAll(fFixed32(3, expires));
        hd.addAll(fBytes(4, tag));
        var sig = fBytes(1, fBytes(1, pub65));
        sig.addAll(fBytes(8, hd));

        var m = fBytes(6, fVarint(1, domain));
        m.addAll(fBytes(7, fBytes(2, addr)));
        m.addAll(fBytes(10, payload));
        m.addAll(fBytes(13, sig));
        m.addAll(fBytes(51, uuid));
        m.addAll(fVarint(52, FLAGS));
        return [m, tag];
    }

    // AES-GCM payload decryption without tag check (CTR mode, counter starts at 2)
    function gcmDecrypt(k, nonce, ct) {
        if (k == null || nonce == null || ct == null || nonce.size() != 12) {
            return null;
        }
        try {
            var aes = new Cryptography.Cipher({
                :algorithm => Cryptography.CIPHER_AES128,
                :mode => Cryptography.MODE_ECB,
                :key => k
            });
            var out = []b;
            var ctr = 2;
            for (var i = 0; i < ct.size(); i += 16) {
                var blk = cat(nonce, u32be(ctr));
                ctr++;
                var ks = aes.encrypt(blk);
                var stop = (i + 16 < ct.size()) ? i + 16 : ct.size();
                for (var j = i; j < stop; j++) {
                    out.add(ct[j] ^ ks[j - i]);
                }
            }
            return out;
        } catch (e) {
            return null;
        }
    }

    // payloads
    function pLock() { return fVarint(2, 1); }
    function pUnlock() { return fVarint(2, 0); }
    // VCSEC closure move: 5 = rear trunk, 6 = front trunk
    function pClosure(which) {
        return fBytes(4, fVarint(which, 1));
    }

    // CarServer vehicle action with an empty message: 26 = flash lights, 27 = honk
    function pAction(field) {
        return fBytes(2, fBytes(field, []b));
    }

    function pClimate(on) {
        var hv = on ? fVarint(1, 1) : []b;
        return fBytes(2, fBytes(10, hv));
    }
}
